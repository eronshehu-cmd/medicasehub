export default function Disclaimer() {
  return (
    <div>
      <h1>Disclaimer Mjekësor</h1>
      <p>
        Përmbajtja e këtij sajti është vetëm për qëllime edukative dhe informuese.
        Ajo nuk zëvendëson këshillën, diagnozën apo trajtimin mjekësor profesional.
      </p>
      <p>
        Rastet e prezantuara janë të bazuara në përvoja të ndara publikisht dhe janë
        anonimizuara. Për çdo shqetësim shëndetësor, konsultohuni gjithmonë me një
        mjek të licencuar.
      </p>
      <p>
        MedicaseHub nuk mban përgjegjësi për vendime të marra bazuar në përmbajtjen
        e këtij sajti.
      </p>
    </div>
  );
}
