export default function About() {
  return (
    <div>
      <h1>Rreth Nesh</h1>
      <p>
        MedicaseHub është një platformë që mbledh dhe analizon raste mjekësore reale,
        me qëllim edukimin dhe informimin e publikut mbi kushte dhe procedura mjekësore.
      </p>
      <p>
        Përmbajtja jonë vjen nga komuniteti r/medicase dhe burime të tjera, e përshtatur
        dhe e strukturuar për lexueshmëri më të mirë.
      </p>
    </div>
  );
}
