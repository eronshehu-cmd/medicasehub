export default function Privacy() {
  return (
    <div>
      <h1>Privacy Policy</h1>
      <p>
        Ky sajt mund të përdorë cookies dhe shërbime të palëve të treta (si Google
        AdSense) për të shfaqur reklama dhe analiza trafiku.
      </p>
      <p>
        Nuk mbledhim informacion personal identifikues nga vizitorët, përveç rasteve
        kur na kontaktoni drejtpërdrejt.
      </p>
      <p>
        Për pyetje rreth privatësisë, na kontaktoni te faqja "Kontakt".
      </p>
    </div>
  );
}
