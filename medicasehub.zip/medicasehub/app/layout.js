export const metadata = {
  title: "MedicaseHub",
  description: "Raste mjekësore reale, analizuar dhe shpjeguar për qëllime edukative.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="sq">
      <body style={{ fontFamily: "sans-serif", margin: 0, padding: 0 }}>
        <header style={{ padding: "1rem 2rem", borderBottom: "1px solid #eee" }}>
          <strong>MedicaseHub</strong>
        </header>
        <main style={{ padding: "2rem", maxWidth: 800, margin: "0 auto" }}>
          {children}
        </main>
        <footer style={{ padding: "2rem", borderTop: "1px solid #eee", marginTop: "3rem", fontSize: "0.85rem", color: "#666" }}>
          © {new Date().getFullYear()} MedicaseHub — Përmbajtja është vetëm për qëllime edukative dhe nuk zëvendëson këshillën mjekësore.
        </footer>
      </body>
    </html>
  );
}
