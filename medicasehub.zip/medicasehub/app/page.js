export default function Home() {
  return (
    <div>
      <h1>MedicaseHub</h1>
      <p>
        Raste mjekësore reale, të analizuara dhe shpjeguara për qëllime edukative dhe informuese.
      </p>
      <p><em>Artikujt e parë do të publikohen së shpejti.</em></p>
    </div>
  );
}
