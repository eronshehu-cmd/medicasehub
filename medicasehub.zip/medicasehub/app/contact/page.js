export default function Contact() {
  return (
    <div>
      <h1>Kontakt</h1>
      <p>Për pyetje, sugjerime, ose kërkesa për heqje përmbajtjeje, na shkruani:</p>
      <p><strong>Email:</strong> info@medicasehub.com</p>
    </div>
  );
}
